const { dbConnection } = require('./db/config');
const express = require('express');

//Cors permite que mi cliente se conecte desde otro servidor

const cors = require('cors')

dbConnection()
require('dotenv').config()

const port = process.env.port



// Crear Server

const app = express();

app.use(express.json())
app.use(cors())


// Ruta Pulic
app.use(express.static('public'))

app.use('/api/midas', require('./routes/midas'))



//Escuchar las peticiones
app.listen( port, ()=>{
    console.log(`Servidor corriendo en el puerto ${port}`)
} )