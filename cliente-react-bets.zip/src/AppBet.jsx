import Header from "./components/Layout/Header"
import Navegacion from "./components/Layout/Navegacion"

import { BrowserRouter, Router, Route, Routes } from 'react-router-dom'
import Nba from "./components/nba/Nba"
import Mlb from "./components/mlb/Mlb"
import Uefa from "./components/uefa/Uefa"
import CrearBet from "./components/nba/CrearBet"
import EditarBet from "./components/nba/EditarBet"


export const AppBet = () => {
  return (
    <BrowserRouter>
    <>
    
        <Header />

        <div className="grid contenedor contenido-principal">
        
        <Navegacion />

        <main className="caja-contenido col-9">
          <Routes>
            //Rutas NBA
            <Route path="/nba"  element={<Nba />}/>
            <Route path="/nba/crear"  element={<CrearBet />}/>
            <Route path="/nba/editar/:id" element={<EditarBet />} />
            

            //Rutas MLB
            <Route path="/mlb"  element={<Mlb />}/>
            <Route path="/uefa"  element={<Uefa />}/>
          </Routes>
         
        </main>

        </div>

       

    </>    
    </BrowserRouter>
  )
}
