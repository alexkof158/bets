const Uefa = () => {
    return ( 
        <h1>Uefa Champions league</h1>
     );
}
 
export default Uefa;