import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import clienteAxios from '../../config/axios';

const EditarBet = () => {
    const { id } = useParams(); // Obtener el id de los parámetros de la URL
    console.log(id)

    useEffect(() => {
        const consultarAPI = async () => {
            try {
                const response = await clienteAxios.get(`/api/midas/editar/${id}`);
                console.log(response.data);
            } catch (error) {
                console.error('Error al obtener los datos de la apuesta:', error);
            }
        };

        consultarAPI();
    }, [id]); // Asegúrate de incluir id en la lista de dependencias

    return (
        <>
            <h1>Editar Apuesta</h1>
            {/* Aquí puedes agregar el formulario de edición de la apuesta */}
        </>
    );
};

export default EditarBet;
