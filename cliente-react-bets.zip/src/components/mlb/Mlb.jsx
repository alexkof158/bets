const Mlb = () => {
    return ( 
        <h1>MLB Bets</h1>
     );
}
 
export default Mlb;