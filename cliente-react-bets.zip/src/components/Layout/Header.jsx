import React from 'react'


const Header = ()=>{
    return (
        <header className="barra">
        <div className="contenedor">
            <h1>CRM - Historial   - Sports</h1>
        </div>
        </header>
    )
}

export default Header;